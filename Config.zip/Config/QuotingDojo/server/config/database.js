const mongoose = require('mongoose');
// Database connection
mongoose.connect('mongodb://localhost/quoting_dojo_config', {useNewUrlParser: true});